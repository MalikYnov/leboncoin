export class ConfigUrlApi{
    
    public delfautUrlApi = "https://leboncoin-malik10.c9users.io/";
    public AdvertForCurrentUserUrlApi:string = ""
    public AdvertUrlApi:string = "https://leboncoin-malik10.c9users.io/adverts"
    public LoginUrlApi:string = "https://leboncoin-malik10.c9users.io/users/login";
    public RegisternUrlApi:string = "https://leboncoin-malik10.c9users.io/users";
    public socketHost:string ="wss://echo.websocket.org/";
    
    
}