import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FormAdvertPage } from './form-advert';

@NgModule({
  declarations: [
    FormAdvertPage,
  ],
  imports: [
    IonicPageModule.forChild(FormAdvertPage),
  ],
})
export class FormAdvertPageModule {}
