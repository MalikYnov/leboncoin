Automatic and manual tests for cordova-plugin-photo-library.
Tests are written with [cordova-plugin-test-framework](https://github.com/apache/cordova-plugin-test-framework). Automatic tests run with [jasmine](https://jasmine.github.io/).

# Running tests

Please use [cordova-plugin-photo-library-tester](https://github.com/terikon/cordova-plugin-photo-library-tester) to run the tests.

# Shims

Tests plugin adds es5, es6 and es7 shims. If needed, update esX-shim.min.js files from node_modules/esX-shim folder.
